-- Load the UI Library
local UI = loadstring(game:HttpGet('https://raw.githubusercontent.com/ApparentlySpooks/spooksUI/refs/heads/main/UI%20Lib'))()

-- Create Tabs
UI.CreateTab("scripts")

UI.CreateButton("Spooks Hub (creator of this ui made this)", function()
	loadstring(game:HttpGet('https://raw.githubusercontent.com/ApparentlySpooks/dandysworldspookshub/refs/heads/main/obfuscated%20spooks%20hub%20dandys%20world.lua'))()
end)

UI.CreateButton("Mox Hub (creator of this ui made this)", function()
	loadstring(game:HttpGet('https://raw.githubusercontent.com/ApparentlySpooks/moxhubV3/refs/heads/main/dandys%20world.txt'))()
end)

UI.CreateButton("Noxious hub", function()
	loadstring(game:HttpGet("https://raw.githubusercontent.com/Noxious-X-Plethora/Noxious-Hub/refs/heads/main/Dandy'sWorldNoxiousHub"))()
end)

UI.CreateButton("Hex Hub", function()
	loadstring(game:HttpGet("https://pastebin.com/raw/ZLZCNatJ"))()
end)

UI.CreateButton("Slendys script", function()
	loadstring(game:HttpGet("https://raw.githubusercontent.com/Slendyvn/Slendys-Dandys-World/refs/heads/main/Slendys%20Dandys%20World"))()
end)

-- Create another Tab
UI.CreateTab("Other scripts")

UI.CreateButton("Infinite Yield", function()
	loadstring(game:HttpGet('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'))()
end)

UI.CreateButton("Dex Explorer", function()
	loadstring(game:HttpGet("https://raw.githubusercontent.com/Babyhamsta/RBLX_Scripts/main/Universal/BypassedDarkDexV3.lua", true))()
end)

UI.CreateTabe("Credits")

UI.CreateButton("antis1212 | creater of script", function()
end)
UI.CreateButton("wealthical | creater of ui, spooks hub, and mox hub", function()
end)
UI.CreateButton("cinno7873 | suport", function()
end)
UI.CreateButton("fezzyfoz | sugestion", function()
end)
UI.CreateButton("slendyyvn | script", function()
end)
UI.CreateButton("ega_biba | script", function()
end)

UI.CreateTabe("Notes")

UI.CreateButton("I did not make these scripts", function()
end)
UI.CreateButton("Some were suggested", function()
end)
UI.CreateButton("Others were just added by me", function()
end)
UI.CreateButton("This is my like 3rd remake of this script", function()
end)